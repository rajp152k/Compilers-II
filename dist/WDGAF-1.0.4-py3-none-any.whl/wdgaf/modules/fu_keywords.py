# the set of keywords available in language
KEYWORDS = [
	'fig',
	'size',
	'step',
]